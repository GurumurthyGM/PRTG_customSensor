Required:
==========
java 8

Setup:
=========
Unzip the application into /opt/
copy nofiyAlarms.service to /etc/systemd/system 

To start/stop application:
service stop/start nofiyAlarms

To tail logs:
journalctl -f

