############################
__author__ = "Guru"

#
# Parameters_required = Eth ports object name
# Live traffic
#############################

import json
import sys
from paepy.ChannelDefinition import CustomSensorResult
from time import sleep

import requests

try:
    data = json.loads(sys.argv[1])
except:
    data = {"host": "172.25.14.126", "params": "Port_Eth-1000-1-7-18"}

ipaddr = data['host']
username = data.get('linuxloginusername', "DIAGUSER")
passwd = data.get('linuxloginpassword', "j72e#05t")
objs = data['params'].split()

if len(objs) == 0:
    result = CustomSensorResult()
    result.add_error(
        "Please provide Eth port's objects as parametes --> Port_Eth OR Port_Eth-cap-c-s-p (@ Additional Parameters while adding sensor)")
    print(result.get_json_result())
    sys.exit(-1)

objlist = '%0A'.join(objs)


def NeSession():
    try:
        session = requests.Session()
        session.auth = (username, passwd)
        session.headers.update({"Cookie": "LOGIN_LEVEL=2; path=/;"})
        return session
    except Exception as e:
        print(e)


def NeGetObjects(ip, Objects):
    try:
        s = NeSession()

        try:
            url = "http://" + ip + ":20080/NMSRequest/IntervalStats?NoHTML=true&Start=0&Last=0&Type=0&Objects=" + Objects
            re = s.get(url)
        except:
            url = "https://" + ip + "/NMSRequest/IntervalStats?NoHTML=true&Start=0&Last=0&Type=0&Objects=" + Objects
            re = s.get(url, verify=False)
        data = re.text.strip()
        # print(data)
        if 'no objects' in data:
            return False
        dataArr = data.splitlines()
        ObjectArr = zip(*(iter(dataArr),) * 3)
        return ObjectArr
    except Exception as e:
        print(e)


PM = NeGetObjects(ipaddr, objlist)
d_pmp = {}
for (x, y, z) in PM:
    d_pmp[x.split()[0]] = dict(zip(y.split(), z.split()))

sleep(5)

PM = NeGetObjects(ipaddr, objlist)
d_pm = {}
for (x, y, z) in PM:
    d_pm[x.split()[0]] = dict(zip(y.split(), z.split()))

# create sensor result
result = CustomSensorResult("BW monitor: {}".format(ipaddr))
for k, v in d_pm.items():
    time_ = int(d_pm[k]["-Timestamp"]) - int(d_pmp[k]["-Timestamp"])
    tx = int(d_pm[k]["-OctetsTransmittedOK"]) - int(d_pmp[k]["-OctetsTransmittedOK"])
    rx = int(d_pm[k]["-OctetsReceivedOK"]) - int(d_pmp[k]["-OctetsReceivedOK"])
    result.add_channel(channel_name="{}_{}".format(k, "TX"), unit="Mbps", value=tx * 8 / time_ / 1048576, is_float=True,
                       decimal_mode='Auto')
    result.add_channel(channel_name="{}_{}".format(k, "RX"), unit="Mbps", value=rx * 8 / time_ / 1048576, is_float=True,
                       decimal_mode='Auto')

print(result.get_json_result())
