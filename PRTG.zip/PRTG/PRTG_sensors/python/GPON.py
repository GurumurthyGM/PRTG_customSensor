import os
from bs4 import BeautifulSoup
import requests
import sys, json
from paepy.ChannelDefinition import CustomSensorResult
import time


#GETTING PARAMETERS
try:
        data = json.loads(sys.argv[1])
except:
        #FORMAT OF "params"=> [CHASIS_NO]-[SLOT_NO]-[GPON_PORT_NO]-[ONT_ID]-[VIRTUAL_ID(=1)]-[ETH_PORT_NUM]
        data = {"host":"192.168.22.162", "linuxloginusername":"DIAGUSER", "linuxloginpassword":"j72e#05t", "params":"1-3-2-4-1-2"}

ip=data.get('host')
username = data.get('linuxloginusername',"DIAGUSER")
passwd = data.get('linuxloginpassword',"j72e#05t")
objs = data['params'].strip().split('-')

def printerror(msg):
        result = CustomSensorResult()
        result.add_error(msg)
        print(result.get_json_result())
        sys.exit(-1)

if len(objs) == 0:
        printerror("Enter Additinal parameters:CI-SI-PI-ONTID-ONTCardID-PortID")


def ActivatedCheck(url):
        condition='''<TR>
	<TH >Physical Status </TH><TD >Activated </TD>
</TR>'''
        s=NeSession()
        re=s.get(url)
        data=re.text
        s.close()
        if condition in data:
                return 1
        else:
                return 0
        
def NeSession():
        try:
                session = requests.Session()
                session.auth = (username, passwd)
                session.headers.update({"Cookie":"LOGIN_LEVEL=2; path=/;"})
                return session
        except Exception as e:
                print (e)


                
def NeGetObjects(add,vlist):#2 functions: To check if ONT exists ; To fetch data from page 
        try:
                #CREATING SESSION WITH IP
                s=NeSession()                                           
                try:
                        re2=s.get(url2)
                        try:
                                re = s.get(add)
                                s.close()
                        except Exception as e: #condition to check if ONT exists
                                return 1
                        data=re.text

                        #PARSING DATA
                        soup=BeautifulSoup(data,'html.parser')       
                        table=soup.table
                        table=soup.find('table')
                        table_rows=table.find_all('tr')
                        for tr in table_rows:
                                td=tr.find_all('td')
                                rows=[i.text for i in td]
                                #STORING PERFROMANCE PARAMATERS TO LIST
                                for perfpar in rows: 
                                        vlist.append(float(perfpar))
                except Exception as e:
                        printerror(e)
                        data = re.text.strip()                         
        
        except Exception as e:
            printerror("Sync button not working")

def PMcheck(url):
    s=NeSession()
    re=s.get(url)
    data=re.text
    s.close()
    if check in data:
            printerror ("***WARNING***: Performance Monitoring is Disabled on ONT. Please enable PM")
            return 0
    else:
            return 1



            


#PARTS OF IPs
part1="http://"+ip+":20080/EMSRequest/"
part2="GPONPerformance?PageType=ETH&instNum="
part3="ViewONTPage?ontgIfNum="
InstNUM=((((((((((int(objs[0]) * 33) + int(objs[1])) * 33) + int(objs[2])) * 129) + int(objs[3])) * 16) + int(objs[4])) * 11) + int(objs[5])) 
ontgIfNum=(((int(objs[0])*10000000)+(int(objs[1])*100000))+(int(objs[2])*1000))+int(objs[3])

#PERFORMANCE MONITORING LINK
url1=part1+part2+str(InstNUM)
#PRESSING SYNC BUTTON LINK
url2=part1+"report"+part2+str(InstNUM)+"&req=5"
#CHECKING IF PM IS DISABLED OR ENABLED LINK
url3=part1+part3+str(ontgIfNum)


#CONDITION IF PERFORMANCE MONIORING IS DISABLED
check='''<SELECT name=enablePm>
<OPTION  SELECTED value=0>Disable</OPTION>
<OPTION  value=1>Enable</OPTION></SELECT> </TD>'''



#perfparlist=[]


#CHECKING IF ONT EXISTS
m=[]#empty dictionary to check if ONT works
ONTcheck=NeGetObjects(url1,m)
if ONTcheck==1:
        printerror("ERROR: ONT DOES NOT EXIST")

else:
    #CHECKING IF ONT IS ACTIVATED OR DEACTIVATED
        ActivationStatus=ActivatedCheck(url3)
        if ActivationStatus==0:
                printerror("ERROR: ONT NOT ACTIVATED. PLEASE CHECK ONT")
        else:
                if(PMcheck(url3)):
                        values1=[]
                        values2=[]
                        NeGetObjects(url1,values1)
                        t1=time.time()
                        time.sleep(5)#5 second gap
                        NeGetObjects(url1,values2)
                        t2=time.time()
                        #print (values1)
                        #print (values2)
                        
                        if values1[16]>values2[16]:
                                Rxvalue=values1[16]-values2[16]
                        else :
                                
                                Rxvalue=values2[16]-values1[16]
                        if values1[21]>values2[21]:
                                Txvalue=values1[21]-values2[21]
                        else :
                                Txvalue=values2[21]-values1[21]
                        #print (values1)
                        #print (values2)
                        #print (t2-t1)
                        #print("Recieving rate in kilobits per second:",((Rxvalue*8)/(t2-t1))/1000)
                        #print("Transmitting rate in kilobits per second:",((Txvalue*8)/(t2-t1))/1000)
                        RX = ((Rxvalue*8)/(t2-t1))/1000
                        TX = ((Txvalue*8)/(t2-t1))/1000
                else:
                        printerror("PM not working. Please enable")
                                

if RX < 0 or TX < 0:
        sys.exit(-1)

result = CustomSensorResult("ONT PM monitor: {}".format(ip))
result.add_channel(channel_name="ONTPM_TX", unit="Mbps", value=TX/1000, is_float=True, decimal_mode='Auto' )
result.add_channel(channel_name="ONTPM_RX", unit="Mbps", value=RX/1000, is_float=True, decimal_mode='Auto' )

print(result.get_json_result())