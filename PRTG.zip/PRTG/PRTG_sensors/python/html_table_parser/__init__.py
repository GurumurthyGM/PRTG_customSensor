from .parser import HTMLTableParser

__author__ = 'Josua Schmid'
__version__ = '0.1.1'
__licence__ = 'AGPLv3'
