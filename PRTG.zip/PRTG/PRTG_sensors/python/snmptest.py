from pysnmp.hlapi import *

errorIndication, errorStatus, errorIndex, varBinds = next(
    getCmd(SnmpEngine(),
           CommunityData('public'),
           UdpTransportTarget(('192.168.22.200', 161)),
           ContextData(),
           ObjectType(ObjectIdentity(".1.3.6.1.4.1.8255.1.2.1.2.144.1.1.31.0.0.5.1.1")),
           ObjectType(ObjectIdentity(".1.3.6.1.4.1.8255.1.2.1.2.144.1.1.32.0.0.5.1.1"))
           )
)


for varBind in varBinds:
    print(varBind[1])
    print(int(varBind[1]))