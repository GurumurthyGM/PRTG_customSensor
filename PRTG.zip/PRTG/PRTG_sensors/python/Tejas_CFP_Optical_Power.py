##########################
__author__="Gurumurthy"
#
#Parameters_required = CFP_Objects seperated space, max 25 eg: MSACFP or MSACFP-1-11-511 MSACFP-1-10-505
#
##########################

import requests
import sys, json
from math import log10,log
from paepy.ChannelDefinition import CustomSensorResult


try:
    requests.packages.urllib3.disable_warnings()
except:
    pass


try:
    data = json.loads(sys.argv[1])
except:
    data = {"host":"172.25.28.115", "linuxloginusername":"tejas", "linuxloginpassword":"j72e#05t", "params":"MSACFP"}

ip=data.get('host')
username = data.get('linuxloginusername1',"DIAGUSER")
passwd = data.get('linuxloginpassword1',"j72e#05t")
objs = data.get('params','MSACFP').strip().split()

def printError(msg):
    result = CustomSensorResult()
    result.add_error(msg)
    print(result.get_json_result())
    sys.exit(-1)

if len(objs) == 0:
    objs = ['MSACFP']

cfplist = '%0A'.join(objs)


def NeSession():
    try:
        session = requests.Session()
        session.auth = (username, passwd)
        session.headers.update({"Cookie":"LOGIN_LEVEL=2; path=/;"})
        return session
    except Exception as e:
        print (e)
    

def CheckNE(ip):
    s = NeSession()
    try:
        url = "http://"+ip+":20080/NMSRequest/IntervalStats?Objects=MSACFP&Start=1&Last=1&Type=0"
        re = s.get(url, timeout=60)
    except:
        url = "https://"+ip+"/NMSRequest/IntervalStats?Objects=MSACFP&Start=1&Last=1&Type=0"
        re = s.get(url, verify=False, timeout=60)

    if not re.status_code == 200:
        printError("NE not reachabled / authentication error!!!")

def NeGetObjects(ip,Objectlist):
    try:
        s = NeSession()
        try:
            url = "http://"+ip+":20080/NMSRequest/GetObjects?NoHTML=true&Objects="+Objectlist
            re = s.get(url, timeout=60)
        except:
            url = "https://"+ip+"/NMSRequest/GetObjects?NoHTML=true&Objects="+Objectlist
            re = s.get(url, verify=False, timeout=60)

        if not re.status_code == 200:
            printError("NE not reachabled / authentication error!!!")
        cfpdata = re.text.strip().splitlines()
        cfps = []
        for cfp in cfpdata:
            info = {}
            infoArr = cfp.split("\t")
            info.update({'ObjectName' : infoArr[0]})
            for i in range(2, len(infoArr[2:]), 2):
                info.update({infoArr[i] : infoArr[i+1]})
            if len(info) > 2:
                cfps.append(info)
        return cfps
    except Exception as e:
        printError(e)

# create sensor result
result = CustomSensorResult("Optical Power monitor on CFPs @: {}".format(ip))
CheckNE(ip)
cfps = NeGetObjects(ip,cfplist)

if len(cfps)==0:
    printError("CFPs not found!!!")
else:
    for cfp in cfps:
        try:
            RX_mW=0
            cfpRX=cfp['-RxPower'].split(";")
            for i in filter(None,cfpRX):
                RX_mW = RX_mW + 10**(float(i.split("=")[1])/10)
            RX_dbm = 10*log10(RX_mW) 
            result.add_channel(channel_name=cfp['-LCTName']+'_Rx', unit="dBm", value=format(RX_dbm, '.2f'),  is_float=True, decimal_mode='Auto')
        except :
            pass
        '''
        try:    
            TX_mW=0
            cfpTX=cfp['-TxPower'].split(";")
            for i in filter(None,cfpTX):
                TX_mW = TX_mW + 10**(float(i.split("=")[1])/10)
            TX_dbm = 10*log10(TX_mW) 
            result.add_channel(channel_name=cfp['-LCTName']+'_Tx', unit="dBm", value=format(TX_dbm, '.2f'), is_float=True, decimal_mode='Auto')
        except:
            pass
        '''

print(result.get_json_result())
