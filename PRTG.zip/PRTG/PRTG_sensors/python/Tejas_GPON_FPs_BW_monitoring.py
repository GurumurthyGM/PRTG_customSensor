"""
# Parameters_required = list of services
# Based on current PM
"""
import json
import sys
from time import sleep
import requests
from paepy.ChannelDefinition import CustomSensorResult

service_fp_dict = {}

try:
	data = json.loads(sys.argv[1])
except:
	data = {"host": "172.25.28.200", "linuxloginusername": "tejas", "linuxloginpassword": "j72e#05t",
			"params": "NMS-ERP101-3"}

ipaddr = data['host']
username = data['linuxloginusername']
password = data['linuxloginpassword']
service_list = data['params'].strip().split()


def printError(msg):
	result = CustomSensorResult()
	result.add_error(msg)
	print(result.get_json_result())
	sys.exit(-1)

if len(service_list) == 0:
    printError("Please provide service names separated by space (@ Additional Parameters while adding sensor)")


def get_ne_session():
	session = requests.Session()
	session.auth = (username, password)
	session.headers.update({"Cookie": "LOGIN_LEVEL=2; path=/;"})
	return session


def get_service_eth_fp():
	fp_service = {}
	try:
		s = get_ne_session()
		uri = "NMSRequest/GetObjects?NoHTML=true&Objects=FlowPoint"
		try:
			url = "http://" + ipaddr + ":20080/" + uri
			re = s.get(url, timeout=60)
		except:
			url = "https://" + ipaddr + "/" + uri
			re = s.get(url, verify=False, timeout=60)

		if not re.status_code == 200:
			printError("NE not reachabled / authentication error!!!")
		fpdata = re.text.strip().splitlines()
		for fp in fpdata:
			info = {}
			infoArr = fp.split("\t")
			for i in range(2, len(infoArr[2:]), 2):
				key, value = infoArr[i], infoArr[i + 1]
				if key == '-LCTName' and value.split("::")[0] in service_list and "FP_ETH" in value:
					info.update({infoArr[0]: value})
					break
			if info:
				fp_service.update(info)
		return fp_service
	except Exception as e:
		printError(e)


def get_pm(Object_list):
	try:
		s = get_ne_session()
		objects = "%0A".join(Object_list)
		uri = "NMSRequest/IntervalStats?NoHTML=true&Start=0&Last=0&Type=0&Objects=" + objects
		try:
			url = "http://" + ipaddr + ":20080/" + uri
			re = s.get(url)
		except:
			url = "https://" + ipaddr + "/" + uri
			re = s.get(url, verify=False)
		data = re.text.strip()
		if 'no objects' in data:
			return False
		dataArr = data.splitlines()
		ObjectArr = zip(*(iter(dataArr),) * 3)
		return ObjectArr
	except Exception as e:
		printError(e)


all_fp = get_service_eth_fp()

fp_list = all_fp.keys()
if len(fp_list) == 0:
	printError("Given services are not available")
PM = get_pm(fp_list)

sleep(3)
sample_pm_1={}
for (x,y,z) in PM:
    sample_pm_1[x.split()[0]] = dict(zip(y.split(),z.split()))

sleep(5)

PM = get_pm(fp_list)
sample_pm_2={}
for (x,y,z) in PM:
    sample_pm_2[x.split()[0]] = dict(zip(y.split(),z.split()))

# create sensor result
result = CustomSensorResult("GPON uplink BW monitor: {}".format(ipaddr))
for k in sample_pm_2.keys():
    time_ = int(sample_pm_2[k]["-Timestamp"]) - int(sample_pm_1[k]["-Timestamp"])
    tx = int(sample_pm_2[k]["-BytesTx64"]) - int(sample_pm_1[k]["-BytesTx64"])
    rx = int(sample_pm_2[k]["-BytesRx64"]) - int(sample_pm_1[k]["-BytesRx64"])
    if tx >= 0 and rx >= 0:
        result.add_channel(channel_name="{}_{}".format(all_fp[k],"TX"), unit="Mbps", value=format(tx*8 / time_ / 1000000, ".3f"), is_float=True)
        result.add_channel(channel_name="{}_{}".format(all_fp[k],"RX"), unit="Mbps", value=format(rx*8 / time_ / 1000000, ".3f"), is_float=True)
  
print(result.get_json_result())

