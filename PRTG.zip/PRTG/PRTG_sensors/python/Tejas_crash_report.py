##########################
__author__="Gurumurthy"
#
#Parameters_required = NONE
#
##########################

import paramiko
import sys,os
import json
from paepy.ChannelDefinition import CustomSensorResult
import pickle
import re
import datetime
import time
import requests

date_time = re.compile("(\d{2}/\d{2}/\d{2} \d{2}:\d{2}:\d{2})")
try:
    data = json.loads(sys.argv[1])
except:
    data = {"host":"172.25.22.188", "linuxloginusername":"tejas", "linuxloginpassword":"j72e#05t", "params":"137267391 172.25.22.189 172.25.22.188 172.25.22.187"}

hip=data.get('host')
username = data.get('linuxloginusername', "DIAGUSER")
passwd = data.get('linuxloginpassword', "j72e#05t")
iplist = data.get("params").strip().split()
TGURL = "https://api.telegram.org/bot695384838:AAGKatWjAHUwrdYuCRif3FSYyzGhtyIDiTs/SendMessage?"
port = 22
channel = iplist[0]

savenodetime = hip+"_crash.p"

message = "Crashed Nodes"
def sendNotification(TO, msg):
    payload = {'chat_id':TO, 'text': msg, 'parse_mode': "HTML"}
    r = requests.post(TGURL,data=payload)
    if "fail" in r.text:
       message =  r.text


def printError(msg):
    result = CustomSensorResult()
    result.add_error(msg)
    print(result.get_json_result())
    sys.exit(-1)


def execute_ssh(ipadd, command):
    ssh=paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(ipadd,port,username,passwd,timeout=120,banner_timeout=120)

    _,stdout,_=ssh.exec_command(command)
    
    data = stdout.read().decode('utf-8')
    return data.strip().splitlines()


def checkcrashdate(lasttime, crashtime):
    if time.strptime(lasttime, "%d/%m/%y %H:%M:%S") < time.strptime(crashtime, "%d/%m/%y %H:%M:%S"):
        return True
    return False

try:
    node_time = pickle.load(open(savenodetime, 'rb'))
except Exception:
    node_time = {}

deftime = datetime.datetime(2018, 4, 13, 00, 00, 00).strftime("%d/%m/%y %H:%M:%S")
crash_count = 0
for node in iplist[1:]:
    try:
        node_crash=['<b>'+node+'</b>']
        crash_list = execute_ssh(node,'grep -ir "stackdump" /etc/tejas/log/crash_info/*')
        for crash in crash_list:
            crashtime = str(date_time.search(crash).group())
            lasttime = str(node_time.get(node,deftime))
            if checkcrashdate(lasttime, crashtime) :
                node_crash.append(crash)
        
        nodetime = execute_ssh(node,'TZ=IST-5:30:0 date +"%d/%m/%y %T"')[0]
        node_time.update({node:nodetime})

        if len(node_crash) > 1:
            sendNotification(channel,"\n\n".join(node_crash))
            crash_count += 1
    except Exception as e:
        #sendNotification(channel, node+"\n"+str(e))
        pass

pickle.dump(node_time, open(savenodetime, 'wb'))

# create sensor result
result = CustomSensorResult("Crash Reporter")

# add primary channel
result.add_channel(channel_name=message, unit="#", value=crash_count, is_float=False, primary_channel=True)

# add additional channel


# print sensor result to stdout
print(result.get_json_result())
