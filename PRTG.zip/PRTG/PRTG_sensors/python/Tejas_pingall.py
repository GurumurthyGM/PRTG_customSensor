##########################
__author__="Gurumurthy"
#
#Parameters_required = NONE
#
##########################
import subprocess
import sys
import json
from paepy.ChannelDefinition import CustomSensorResult
import pickle
import requests

try:
    data = json.loads(sys.argv[1])
except:
    data = {"host":"172.25.100.233", "linuxloginusername":"tejas", "linuxloginpassword":"j72e#05t", "params":"137267391 172.25.100.237 172.25.100.233 172.25.23.10"}

hip=data.get('host')
#username = data.get('linuxloginusername', "DIAGUSER")
#passwd = data.get('linuxloginpassword', "j72e#05t")
iplist = data.get("params").strip().split()
TGURL = "https://api.telegram.org/bot695384838:AAGKatWjAHUwrdYuCRif3FSYyzGhtyIDiTs/SendMessage?"
port = 22
channel = iplist[0]

urnodesfile = hip+"_ping.p"

def sendNotification(TO, msg):
    payload = {'chat_id':TO, 'text': msg, 'parse_mode': "HTML"}
    r = requests.post(TGURL,data=payload)
    if "fail" in r.text:
       message =  r.text


def printError(msg):
    result = CustomSensorResult()
    result.add_error(msg)
    print(result.get_json_result())
    sys.exit(-1)


def ping(ipadd):
    r,out = subprocess.getstatusoutput("ping -n 5 -l 64 "+ipadd)
    print(out)
    if "bytes=64" in out:
        return True
    return False


try:
    URnodes = pickle.load(open(urnodesfile, 'rb'))
except Exception:
    URnodes = set()

lastURnodes = set(URnodes)
urnodenow = set()
for node in iplist[1:]:
    try:
        if ping(node) is False:
            if node not in URnodes:
                urnodenow.add(node)
            URnodes.add(node)
        else:
            if node in URnodes:
                URnodes.remove(node)

    except Exception as e:
        sendNotification(channel, node+"\n"+str(e))

pickle.dump(URnodes, open(urnodesfile, 'wb'))

nrlist = "\n".join(urnodenow)
rnodesnow = lastURnodes - URnodes

if len(urnodenow):
    sendNotification(channel, "<b>Unreachable nodes:</b>\n"+nrlist)
if len(rnodesnow):
    sendNotification(channel, "<b>Nodes became reachable:</b>\n"+"\n".join(rnodesnow))
# create sensor result
result = CustomSensorResult("Ping all and notify::\n Unavailable NEs:"+''.join(URnodes))

# add primary channel
result.add_channel(channel_name="Unreachable NEs", unit="#", value=len(URnodes), is_float=False, primary_channel=True)

# add additional channel


# print sensor result to stdout
print(result.get_json_result())
