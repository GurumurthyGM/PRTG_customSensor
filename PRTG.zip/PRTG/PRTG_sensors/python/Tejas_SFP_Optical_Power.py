##########################
__author__= 'Gurumurthy'
#
#Parameters_required = SFP_Objects seperated space max 25 eg: SFP-1-11-1 SFP-1-10-5
#
##########################


import requests
import sys, json
from paepy.ChannelDefinition import CustomSensorResult


try:
    requests.packages.urllib3.disable_warnings()
except:
    pass

try:
    data = json.loads(sys.argv[1])
except:
    data = {"host":"172.25.28.102", "linuxloginusername":"DIAGUSER", "linuxloginpassword":"j72e#05t", "params":""}


ip=data.get('host')
username = data.get('linuxloginusername1',"DIAGUSER")
passwd = data.get('linuxloginpassword1',"j72e#05t")
objs = data['params'].strip().split()


def printError(msg):
    result = CustomSensorResult()
    result.add_error(msg)
    print(result.get_json_result())
    sys.exit(-1)

if len(objs) == 0:
    objs = ["SFP"]

sfplist = "%0A".join(objs)


def NeSession():
    try:
        session = requests.Session()
        session.auth = (username, passwd)
        session.headers.update({"Cookie":"LOGIN_LEVEL=2; path=/;"})
        return session
    except Exception as e:
        print (e)

def CheckNE(ip):
    s = NeSession()
    try:
        url = "http://"+ip+":20080/NMSRequest/IntervalStats?Objects=SFP&Start=1&Last=1&Type=0"
        re = s.get(url, timeout=60)
    except:
        url = "https://"+ip+"/NMSRequest/IntervalStats?Objects=SFP&Start=1&Last=1&Type=0"
        re = s.get(url, verify=False, timeout=60)

    if not re.status_code == 200:
        printError("NE not reachabled / authentication error!!!")


def NeGetObjects(ip,ObjectList):
    try:
        s = NeSession()
        try:
            url = "http://"+ip+":20080/NMSRequest/GetObjects?NoHTML=true&Objects="+ObjectList
            re = s.get(url, timeout=60)
        except:
            url = "https://"+ip+"/NMSRequest/GetObjects?NoHTML=true&Objects="+ObjectList
            re = s.get(url, verify=False, timeout=60)
        if not re.status_code == 200:
            printError("NE not reachabled / authentication error!!!") 
        sfpdata = re.text.strip().splitlines()
        sfps = []
        for sfp in sfpdata:
            info = {}
            infoArr = sfp.split("\t")
            info.update({'ObjectName' : infoArr[0]})
            for i in range(2, len(infoArr[2:])+1, 2):
                info.update({infoArr[i] : infoArr[i+1]})
            if len(info) > 2:
                sfps.append(info)
        return sfps
    except Exception as e:
        printError(e)
        return False

# create sensor result
result = CustomSensorResult("Optical Power monitor on SFPs @: "+ip)
CheckNE(ip)
sfps = NeGetObjects(ip,sfplist)
if not sfps:
    printError("SFPs not Found!!!")
portslist  = []
for port in sfps:
    portslist.append(port.get("-Parent"))

Ports = NeGetObjects(ip,"%0A".join(portslist))

for sfp in sfps:
    for pn in Ports:
        if pn.get("ObjectName") == sfp.get("-Parent"):
            PortName = pn.get("-LCTName")
            if "ETH" in PortName:
                PortName = sfp.get("-Parent")
            break

    rx=sfp.get('-RxPower')
    tx=sfp.get('-TxPower')
    try:
        _ = int(float(rx)) #to filter -inf and NaN 
        RX = float(rx)
    except:
        RX=-100

    try:
        _ = int(float(tx)) #to filter -inf and NaN 
        TX = float(tx) 
    except :
        TX = -100
    result.add_channel(channel_name=PortName+'_Rx', unit="dBm", value=format(RX, '.2f'), is_float=True, decimal_mode='Auto')
    #result.add_channel(channel_name=PortName+'_Tx', unit="dBm", value=format(TX, '.2f'), is_float=True, decimal_mode='Auto')
print(result.get_json_result())
