##########################
__author__= 'Gurumurthy'
#
#Parameters_required = SFP_Objects seperated space max 25 eg: SFP-1-11-1 SFP-1-10-5
#
##########################


import requests
import sys, json
from paepy.ChannelDefinition import CustomSensorResult

try:
    requests.packages.urllib3.disable_warnings()
except:
    pass

try:
    data = json.loads(sys.argv[1])
except:
    data = {"host":"172.25.28.102", "linuxloginusername":"DIAGUSER", "linuxloginpassword":"j72e#05t", "params":""}

ip=data.get('host')
username = data.get('linuxloginusername',"DIAGUSER ")
passwd = data.get('linuxloginpassword',"j72e#05t")

def printError(msg):
    result = CustomSensorResult()
    result.add_error(msg)
    print(result.get_json_result())
    sys.exit(-1)

def NeSession():
    try:
        session = requests.Session()
        session.auth = (username, passwd)
        session.headers.update({"Cookie":"LOGIN_LEVEL=2; path=/;"})
        return session
    except Exception as e:
        print (e)
    

def NeGetObjects(ip,ObjectList):
    try:
        s = NeSession()
        try:
            url = "http://"+ip+":20080/NMSRequest/GetObjects?NoHTML=true&Objects="+ObjectList
            re = s.get(url, timeout=60)
        except:
            url = "https://"+ip+"/NMSRequest/GetObjects?NoHTML=true&Objects="+ObjectList
            re = s.get(url, verify=False, timeout=60)
            
        if not re.status_code == 200:
            printError("NE not reachabled / authentication error!!!") 
        datas = re.text.strip().splitlines()
        datalist = []
        for data in datas:
            info = {}
            infoArr = data.split("\t")
            info.update({'ObjectName' : infoArr[0]})
            for i in range(2, len(infoArr[2:]), 2):
                info.update({infoArr[i] : infoArr[i+1]})
            if len(info) > 2:
                datalist.append(info)
        return datalist
    except Exception as e:
        printError(e)
        

TrunkList = NeGetObjects(ip,'Trunk')
PacketList = NeGetObjects(ip,'PacketTrunk')

Ports = [] 
for trunk in TrunkList:
    _,ci,si,pn,_,_ = trunk.get("ObjectName").split('-')
    capacity = trunk.get("-Capacity")  
    PortObj = '{}-{}-{}-{}'.format("SFP", ci, si, pn)
    if 'ODU' in capacity:
        pn = int(pn)-500
        capacity=capacity.replace('ODU', 'OTU')
    PortName = '{}-{}-{}-{}'.format(capacity, ci, si, pn)
    Ports.append({"ObjectName":PortObj, "PortName":PortName})

for Ptrunk in PacketList:
    PortObj = '{}-{}-{}-{}'.format("SFP",Ptrunk.get('-CI'),Ptrunk.get('-SI'),Ptrunk.get('-PN'))
    PortName = '{}_{}-{}-{}-{}'.format("ETH",Ptrunk.get('-Capacity'),Ptrunk.get('-CI'),Ptrunk.get('-SI'),Ptrunk.get('-PN'))
    Ports.append({"ObjectName":PortObj, "PortName":PortName})

if not Ports:
    printError("No TLs found!!!")


sfpobjs = '%0A'.join([obj.get("ObjectName") for obj in Ports ])

sfppower = NeGetObjects(ip, sfpobjs)

if len(sfppower)==0:
    printError("SFPs not found!!!")

result = CustomSensorResult("Optical Power monitor on SFPs @: "+ip)

for sfp in sfppower:
    for port in Ports:
        if sfp.get("ObjectName") == port.get("ObjectName"):
            rx=sfp.get('-RxPower')
            tx=sfp.get('-TxPower')
            try:
                RX = float(rx) if rx != '-inf' else -100
            except:
                RX=-100
            try:
                TX = float(tx) if tx != '-inf' else -100
            except :
                TX = -100
            result.add_channel(channel_name=port.get('PortName'), unit="dBm", value=format(RX, '.2f'), is_float=True, decimal_mode='Auto')
            #result.add_channel(channel_name=port.get('PortName')+'_Rx', unit="dBm", value=RX, is_float=True, decimal_mode='Auto')
            #result.add_channel(channel_name=port.get('PortName')+'_Tx', unit="dBm", value=TX, is_float=True, decimal_mode='Auto')

print(result.get_json_result())
